const Controlled = (props) => {
  console.log(props);

  return (
    <>
      <input type="email" ref={props.ref} />
    </>
  );
};

export default Controlled;
